import java.util.ArrayList;
import java.util.List;

public class Example6 {

	public static void main(String[] args) {

		List<Dog> list = new ArrayList<>();
		list.add(new Dog("aa", 1));
		list.add(new Dog("bb", 4));
		list.add(new Dog("cc", 3));
		list.add(new Dog("dd", 2));
		list.add(new Dog("ee", 5));

		// sort a list
		System.out.println("lambda sort");
		list.sort((o1, o2) -> o1.getAge() - o2.getAge());
		System.out.println(list);

		// iterate the elements
		System.out.println("lambda forEach");
		list.forEach(System.out::println);
	}
}
