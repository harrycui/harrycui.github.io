
public class Example5 {
	public static void main(String[] args) {

		// common use
		DogService dogService = () -> {
			return new Dog();
		};
		dogService.getDog();

		// simplified version
		DogService dogService2 = () -> new Dog();
		dogService2.getDog();

		// constructor
		DogService dogService3 = Dog::new;
		dogService3.getDog();

		// constructor with parameters
		DogService2 dogService21 = Dog::new;
		dogService21.getDog("Fantasy", 6);
	}
}
