
public class Example1 {

	public static void main(String[] args) {
		
		Cal c1 = new Cal() {
			@Override
			public int add(int a, int b) {
				return a + b;
			}
		};
		
		int c = c1.add(1, 2);
		
		System.out.println(c);
	}

	interface Cal {
		int add(int a, int b);
	}
}

// Change line 6 - 11
// Cal c1=(int a,int b) ->{return a+b;};