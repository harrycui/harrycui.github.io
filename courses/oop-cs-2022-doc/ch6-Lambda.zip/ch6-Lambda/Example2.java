
public class Example2 {

	public static void main(String[] args) {

		// no parameter & no return value
		If1 if1 = () -> {
			System.out.println("no parameter & no return value");
		};
		if1.test();

		// one parameter & no return value
		If2 if2 = (int a) -> {
			System.out.println("one parameter & no return value: a=" + a);
		};
		if2.test(3);

		// two parameters & no return value
		If3 if3 = (int a, int b) -> {
			System.out.println("two parameters & no return value: a+b=" + (a + b));
		};
		if3.test(2, 3);

		// no parameter & a return value
		If4 if4 = () -> {
			System.out.print("no parameter & a return value: ");
			return 100;
		};
		System.out.println(if4.test());

		// one parameter & a return value
		If5 if5 = (int a) -> {
			System.out.print("one parameter & a return value: ");
			return a;
		};
		System.out.println(if5.test(200));

		// two parameters & a return value
		If6 if6 = (int a, int b) -> {
			System.out.print("two parameters & a return value: ");
			return a + b;
		};
		System.out.println(if6.test(1, 2));
	}
}

interface If1 {

	/**
	 * no parameter & no return value
	 */
	void test();
}

interface If2 {

	/**
	 * one parameter & no return value
	 * 
	 * @param a
	 */
	void test(int a);
}

interface If3 {

	/**
	 * two parameters & no return value
	 * 
	 * @param a
	 * @param b
	 */
	void test(int a, int b);
}

interface If4 {

	/**
	 * no parameter & a return value
	 * 
	 * @return
	 */
	int test();
}

interface If5 {

	/**
	 * a parameter & a return value
	 * 
	 * @param a
	 * @return
	 */
	int test(int a);
}

interface If6 {

	/**
	 * two parameters & a return value
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	int test(int a, int b);
}