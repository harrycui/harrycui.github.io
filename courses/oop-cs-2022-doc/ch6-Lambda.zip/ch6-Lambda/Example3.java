
public class Example3 {

	public static void main(String[] args) {

		// 1. If parameter types can be inferred, you can omit them.
		// 2. If there is only one parameter, the parentheses () can be omitted.
		// 3. If there is only one expression, the braces {} can be omitted.
		// 4. If there is only one return statement, then both the braces {} and the
		// keyword return can be omitted together.

		// no parameter & no return value
		If1 if1 = () -> System.out.println("no parameter & no return value");
		if1.test();

		// one parameter & no return value
		If2 if2 = a -> System.out.println("one parameter & no return value: a=" + a);
		if2.test(3);

		// two parameters & no return value
		If3 if3 = (a, b) -> {
			System.out.println("two parameters & no return value: a+b=" + (a + b));
		};
		if3.test(2, 3);

		// no parameter & a return value
		If4 if4 = () -> 100;
		System.out.println(if4.test());

		// one parameter & a return value
		If5 if5 = a -> {
			System.out.print("one parameter & a return value ");
			return a;
		};
		System.out.println(if5.test(200));

		// two parameters & a return value
		If6 if6 = (a, b) -> a + b;
		System.out.println(if6.test(1, 2));

	}
}