import java.util.ArrayList;
import java.util.List;

public class Example4 {

	public static void main(String[] args) {
		
		// Method references
		// Syntax:
		//     object::instanceMethod
		//     Class::staticMethod
		//     Class::instanceMethod

		Example4 program4 = new Example4();
		If5 if5 = program4::test;
		If5 if52 = Example4::test2;
		System.out.println(if5.test(1));
		System.out.println(if52.test(1));
		
		List<Example4> list = new ArrayList<>();
		list.add(new Example4());
		list.add(new Example4());
		list.add(new Example4());
		list.add(new Example4());
		
		list.forEach(Example4::test3);
	}

	public int test(int a) {
		return a - 2;
	}

	public static int test2(int a) {
		return a - 2;
	}
	
	public void test3() {
		System.out.println("Class::instanceMethod");
	}
}