
public class InsufficientMoneyException extends Exception {

	private double amount; // refers to the amount of money that the account lacks
	
	public InsufficientMoneyException(double amount) {
		this.amount = amount;
	}
	
	public double getAmount() {
		return amount;
	}
}
