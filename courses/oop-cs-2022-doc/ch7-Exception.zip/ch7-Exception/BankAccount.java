
public class BankAccount {
	
	private double balance;
	private int id;			// account id
	
	public BankAccount(int id) {
		this.id = id;
	}
	
	public double getBalance() {
		return balance;
	}

	public int getId() {
		return id;
	}
	
	public void deposit(double amount) {
		balance += amount;
	}
	
	public void withdraw(double amount) throws InsufficientMoneyException {
		if (balance >= amount) {
			balance -= amount;
		} else {
			double needs = amount - balance;
			throw new InsufficientMoneyException(needs);
		}
	}
}
